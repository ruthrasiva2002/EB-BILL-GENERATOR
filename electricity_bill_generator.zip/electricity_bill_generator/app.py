from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'
def init_db():
    with sqlite3.connect('electricity.db') as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                units INTEGER,
                total_amount REAL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                door_no TEXT NOT NULL,
                address TEXT NOT NULL,
                pincode TEXT NOT NULL
            )
        ''')
        conn.commit()
                
# Initialize the database
init_db()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect('electricity.db') as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect('electricity.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username=? AND password=?', (username, password))
            user = cursor.fetchone()
            if user:
                session['user_id'] = user[0]
                return redirect(url_for('add_customer'))
    return render_template('login.html')

@app.route('/add_customer', methods=['GET', 'POST'])
def add_customer():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        # Get the additional customer information
        name = request.form['name']
        door_no = request.form['door_no']
        address = request.form['address']
        pincode = request.form['pincode']
        units = int(request.form['units'])
        
        total_amount = calculate_bill(units)
        user_id = session['user_id']
        
        with sqlite3.connect('electricity.db') as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO bills (user_id, units, total_amount) VALUES (?, ?, ?)', 
                           (user_id, units, total_amount))
            # You may want to create a separate table for customer details
            cursor.execute('INSERT INTO customers (name, door_no, address, pincode) VALUES (?, ?, ?, ?)', 
                            (name, door_no, address, pincode))
            conn.commit()
        
        return render_template('bill.html', total_amount=total_amount, units=units)
    
    return render_template('add_customer.html')

def calculate_bill(units):
    if units <= 100:
        amount = units * 1.0  # Per unit price in dollars
    elif units <= 200:
        amount = 100 * 1.0 + (units - 100) * 1.5
    elif units <= 300:
        amount = 100 * 1.0 + 100 * 1.5 + (units - 200) * 2.0
    elif units <= 500:
        amount = 100 * 1.0 + 100 * 1.5 + 100 * 2.0 + (units - 300) * 2.5
    else:
        amount = 100 * 1.0 + 100 * 1.5 + 100 * 2.0 + 200 * 2.5 + (units - 500) * 3.0

    # Convert to INR (Assume $1 = ₹83)
    return round(amount * 83, 2)

@app.route('/admin')
def admin():
    with sqlite3.connect('electricity.db') as conn:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT b.id, b.user_id, c.name, c.door_no, c.address, c.pincode, 
                   b.units, b.total_amount 
            FROM bills AS b
            JOIN customers AS c ON b.user_id = c.rowid
        ''')
        bills = cursor.fetchall()
    
    return render_template('admin.html', bills=bills)


@app.route('/logout')  # Make sure this route exists
def logout():
    session.pop('user', None)  # Example: Clear session
    return redirect(url_for('login'))  # Redirect to login


if __name__ == '__main__':
    app.run(debug=True)